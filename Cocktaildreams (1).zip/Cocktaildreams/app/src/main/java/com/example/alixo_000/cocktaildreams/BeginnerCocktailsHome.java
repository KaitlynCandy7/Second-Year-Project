package com.example.alixo_000.cocktaildreams;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

public class BeginnerCocktailsHome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beginner_cocktails_home);
        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);}

    public void sendMessage(View view){
        Intent startNewActivity = new Intent(this, Gimlet.class);
            startActivity(startNewActivity);
    }
    public void sendMeme(View view){
        Intent startNewActivity = new Intent(this, Daiquiri.class);
        startActivity(startNewActivity);
    }
    public void sendMem(View view){
        Intent startNewActivity = new Intent(this, Cosmopolitan2.class);
        startActivity(startNewActivity);
    }

    public void sendMe(View view){
        Intent startNewActivity = new Intent(this, Negroni.class);
        startActivity(startNewActivity);
    }
    public void sendM(View view){
        Intent startNewActivity = new Intent(this, Sidecar.class);
        startActivity(startNewActivity);
    }



       // FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
       // fab.setOnClickListener(new View.OnClickListener() {
            //@Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
       // });
   // }

}
